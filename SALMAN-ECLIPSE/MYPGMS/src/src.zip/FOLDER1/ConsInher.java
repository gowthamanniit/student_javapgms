package FOLDER1;

class person
{
	person()
	{
				
	}	
}

public class ConsInher {
	public static void main(String[] args) {
		person p=new person();
		
	}
}
