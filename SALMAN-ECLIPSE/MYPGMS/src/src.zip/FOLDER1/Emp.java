package FOLDER1;

public class Emp {
		int k=10;
		private int s=20;  // private var work only with in a class
		protected int m=30;
		public int t=40;
}
