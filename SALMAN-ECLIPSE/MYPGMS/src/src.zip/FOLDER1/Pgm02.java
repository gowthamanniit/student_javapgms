package FOLDER1;

public class Pgm02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("program 2 using eclipse");
	}

}
