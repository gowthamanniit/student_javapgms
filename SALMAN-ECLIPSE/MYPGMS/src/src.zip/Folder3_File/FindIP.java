package Folder3_File;


import java.net.InetAddress;

public class FindIP {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub

		InetAddress ip=InetAddress.getLocalHost();
		System.out.println("my ip:"+ip);
		
	}

}
