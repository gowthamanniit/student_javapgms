package FOLDER2;
import FOLDER1.*;
public class Pgm03 extends Emp{
	void dis()
	{
		
	}
}
