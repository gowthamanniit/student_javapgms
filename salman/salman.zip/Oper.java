
class Oper
{
 public static void main(String args[])
 {
   int a=4;
   int b=5;

   int ans;
   ans=a&b;

   System.out.println(" bit wise & value : "+ans);
  System.out.println(" bit wise | value : "+ (a|b));
  System.out.println(" bit wise ^ value : "+ (a^b));

 }
}
/*
0000-0
0001-1
0010-2
0011-3
0100-4
0101-5
0110-6
0111-7
1000-8
1001-9
1010-10
1011-11
1100-12
1101-13
1110-14
1111-15

*/