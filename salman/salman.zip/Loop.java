class Loop
{
 public static void main(String args[])
 {
	int i=5;
	do
	{
	i--;
  System.out.print(i+"  ");  // 4 3 2 1 0 -1 -1
	}	
	while(i>=0);
	System.out.print(i);
 }
}